#!/usr/bin/env python3
"""Birthday greeting script.

Usage:
    python birthday.py <name> <age>

Prints a birthday message using the provided name and age.
"""

import argparse
import sys

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description='Print a birthday message.')
    parser.add_argument('name', help='Name of the person')
    parser.add_argument('age', type=int, help='Age of the person (integer)')
    return parser.parse_args(argv)

def main():
    args = parse_args()
    name = args.name
    age = args.age
    if age < 0:
        print('Error: Age cannot be negative.', file=sys.stderr)
        sys.exit(1)
    print(f'Happy Birthday, {name}! You are now {age} years old!')

if __name__ == '__main__':
    main()
