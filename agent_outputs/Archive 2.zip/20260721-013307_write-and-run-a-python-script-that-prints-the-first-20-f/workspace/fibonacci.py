def generate_fibonacci(n):
    fib_sequence = [0, 1]
    while len(fib_sequence) < n:
        fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
    return fib_sequence

def main():
    n = 20
    fib_numbers = generate_fibonacci(n)
    print(f"First {n} Fibonacci numbers:")
    print(fib_numbers)

if __name__ == "__main__":
    main()