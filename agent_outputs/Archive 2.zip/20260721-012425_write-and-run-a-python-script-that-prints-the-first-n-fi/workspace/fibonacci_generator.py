import sys

timeout = 5  # seconds

def fibonacci(n):
    fib_sequence = [0, 1]
    while len(fib_sequence) < n:
        fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
    return fib_sequence[:n]

try:
    n = int(input("Enter the number of Fibonacci numbers to generate: "))
    if n <= 0:
        print("Please enter a positive integer.")
    else:
        fib_numbers = fibonacci(n)
        print(fib_numbers)
except ValueError:
    print("Invalid input. Please enter a positive integer.")