# ReAct Agent (Python)

**Location:** `plan-execute-agent-scaffold/src/agents/react/`

## Overview

The **ReAct** (Reason+Act) agent is a Python implementation of the *reasoning‑and‑acting* pattern popularised by the "ReAct: Synergizing Reasoning and Acting in Language Models" paper.  It enables a language model to interleave **thought** (chain‑of‑thought reasoning) with **actions** (tool calls, environment interactions) in a single, coherent loop.

Unlike the React JavaScript library, this package has nothing to do with UI components – it is a **decision‑making agent** that:

1. **Generates a reasoning step** (a natural‑language thought).
2. **Decides whether to act** based on that thought.
3. **Executes the chosen tool/action** (e.g., web search, database query, file I/O).
4. **Feeds the observation back** to the language model for the next iteration.

The loop continues until the model produces a final answer or a termination condition is met.

---

## Architecture

```
react/
├── __init__.py
├── agent.py          # Core ReActAgent class – orchestrates the loop
├── prompts.py        # Prompt templates (system, thought, action, observation)
├── tools.py          # Abstract Tool base class + concrete tool implementations
├── utils.py          # Helper functions (parsing, logging, token budgeting)
└── config.py         # Default configuration values (max_steps, temperature, etc.)
```

### Core Components

| File | Primary Class / Function | Responsibility |
|------|--------------------------|----------------|
| `agent.py` | **`ReActAgent`** | Drives the reasoning‑acting cycle. Handles LLM calls, parses model output, dispatches actions, and aggregates observations. |
| `prompts.py` | `SYSTEM_PROMPT`, `THOUGHT_PROMPT`, `ACTION_PROMPT` | Centralised prompt strings that keep the interaction format consistent across calls. |
| `tools.py` | **`Tool`** (ABC) and concrete subclasses (`SearchTool`, `CalculatorTool`, `FileReadTool`, …) | Defines the contract for any external capability the agent can invoke. Each tool implements `run(params: dict) -> str`. |
| `utils.py` | `parse_model_output`, `format_action`, `truncate_history` | Parsing utilities to extract `Thought`, `Action`, and `Observation` blocks from the LLM response. Also contains safe‑truncation of the message history to respect token limits. |
| `config.py` | `DEFAULT_CONFIG` | Holds sensible defaults (e.g., `max_steps=10`, `temperature=0.0`). Users can override via the `ReActAgent` constructor. |

---

## Quick Start

### Installation

```bash
# Inside the scaffold repository root
pip install -e .   # Installs the package in editable mode
```

Make sure you have an OpenAI‑compatible API key set in the environment:

```bash
export OPENAI_API_KEY='sk-...'
```

### Basic Usage

```python
from plan_execute_agent_scaffold.agents.react.agent import ReActAgent
from plan_execute_agent_scaffold.agents.react.tools import SearchTool, CalculatorTool

# Initialise the agent with a set of tools it may call
agent = ReActAgent(
    tools=[SearchTool(), CalculatorTool()],
    max_steps=8,
    temperature=0.0,
)

question = "What is the current population of Tokyo and how does it compare to the population of New York City?"
answer = agent.run(question)
print("Final answer:", answer)
```

### Expected Interaction Flow

1. **System Prompt** – Provides the model with the overall task description and the list of available tools.
2. **User Message** – The original query.
3. **Model Output** – Returns a block containing a `Thought:` line, optionally followed by an `Action:` line.
4. **Agent Parses** – Detects an action, calls the corresponding tool, captures the observation.
5. **Observation Injection** – The observation is appended to the conversation and the loop repeats.
6. **Termination** – When the model outputs a `Final Answer:` block, the loop stops and the answer is returned.

---

## Extending the Agent

### Adding a New Tool

1. Subclass `Tool` in `tools.py`.
2. Implement the `name`, `description`, and `run(self, params: dict) -> str` methods.
3. Register the new tool when constructing `ReActAgent`.

```python
from plan_execute_agent_scaffold.agents.react.tools import Tool

class WeatherTool(Tool):
    name = "weather"
    description = "Fetches current weather for a given city."

    def run(self, params: dict) -> str:
        city = params.get("city")
        # Imagine we call an external API here …
        return f"The weather in {city} is sunny, 22°C."
```

### Custom Prompt Templates

If you need a domain‑specific prompt, edit `prompts.py` or pass a custom `system_prompt` to the agent:

```python
custom_prompt = "You are a finance‑focused ReAct agent. ..."
agent = ReActAgent(system_prompt=custom_prompt, tools=[...])
```

---

## Configuration Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `max_steps` | `int` | `10` | Maximum number of reasoning‑acting iterations before forced termination. |
| `temperature` | `float` | `0.0` | Sampling temperature for the LLM. Lower values make the agent deterministic. |
| `model_name` | `str` | `gpt-4o-mini` | The OpenAI model used for reasoning. |
| `system_prompt` | `str` | *provided in `prompts.py*` | Override the base system prompt. |
| `verbose` | `bool` | `False` | If `True`, prints each Thought/Action/Observation to stdout for debugging. |

---

## How It Differs From the React JavaScript Framework

| Aspect | ReAct (Python) | React (JS) |
|--------|----------------|------------|
| Domain | Language‑model reasoning & tool use | UI component rendering |
| Core Concept | Interleaved *thought* and *action* loops | Declarative UI with virtual DOM |
| Execution Model | Sequential LLM calls + external tool invocations | Event‑driven component re‑rendering |
| Output | Natural‑language answer (or structured data) | HTML/DOM tree |
| Extensibility | Add new **Tool** classes to give the agent new capabilities | Add new components, hooks, or libraries |

---

## Testing

The repository includes a small test suite under `tests/react/`.

```bash
pytest -q tests/react
```

Key tests verify:
- Correct parsing of `Thought:` / `Action:` blocks.
- Proper dispatch to the appropriate tool.
- Loop termination after `max_steps`.
- Deterministic output when `temperature=0`.

---

## License

This project is licensed under the **MIT License**. See the top‑level `LICENSE` file for details.

---

## References

- **ReAct Paper:** *Synergizing Reasoning and Acting in Language Models* – https://arxiv.org/abs/2210.03629
- **OpenAI API Documentation** – https://platform.openai.com/docs/api-reference

---

*Happy building!*