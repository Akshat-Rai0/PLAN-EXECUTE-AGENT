#!/usr/bin/env python3
"""birthday.py

A simple script that accepts a name and age via command‑line arguments and prints a birthday message.

Usage:
    python birthday.py --name Alice --age 30
"""

import argparse
import sys

def parse_args(argv=None):
    """Parse command‑line arguments.

    Parameters
    ----------
    argv: list of str, optional
        Argument list to parse. If ``None`` (default), ``sys.argv[1:]`` is used.

    Returns
    -------
    argparse.Namespace
        Parsed arguments with attributes ``name`` and ``age``.
    """
    parser = argparse.ArgumentParser(
        description="Print a birthday message for the given name and age."
    )
    parser.add_argument(
        "--name",
        required=True,
        help="The name of the person whose birthday is being celebrated.",
    )
    parser.add_argument(
        "--age",
        type=int,
        required=True,
        help="The age of the person after the birthday.",
    )
    return parser.parse_args(argv)


def main():
    args = parse_args()
    # Basic validation: age should be a non‑negative integer.
    if args.age < 0:
        print("Error: age cannot be negative.", file=sys.stderr)
        sys.exit(1)
    print(f"Happy Birthday, {args.name}! You are now {args.age} years old.")


if __name__ == "__main__":
    main()
