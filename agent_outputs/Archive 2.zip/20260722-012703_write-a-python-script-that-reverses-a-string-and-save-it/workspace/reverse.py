#!/usr/bin/env python3
"""
reverse.py - Reverse a string.

Provides a function `reverse_string(s)` that returns the reversed string.
When run as a script, it accepts a string argument (or reads from stdin) and prints the reversed result.
"""

import sys
import argparse

def reverse_string(s: str) -> str:
    """Return the reverse of the input string."""
    return s[::-1]

def main():
    parser = argparse.ArgumentParser(description="Reverse a given string.")
    parser.add_argument('string', nargs='?', help='String to reverse. If omitted, reads from stdin.')
    args = parser.parse_args()

    if args.string is not None:
        input_str = args.string
    else:
        input_str = sys.stdin.read().rstrip('\\n')
    print(reverse_string(input_str))

if __name__ == "__main__":
    main()
