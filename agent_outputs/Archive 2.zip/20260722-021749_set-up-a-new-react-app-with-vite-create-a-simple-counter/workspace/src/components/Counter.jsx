import React, { useState } from 'react';

const Counter = () => {
  const [count, setCount] = useState(0);

  const increment = () => setCount(prev => prev + 1);
  const decrement = () => setCount(prev => prev - 1);

  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <h2>Counter</h2>
      <p style={{ fontSize: '2rem' }}>{count}</p>
      <button onClick={decrement} style={{ marginRight: '1rem' }}>-</button>
      <button onClick={increment}>+</button>
    </div>
  );
};

export default Counter;
